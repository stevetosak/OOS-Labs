OOS Lab-2-Docker, Zadaca-2
